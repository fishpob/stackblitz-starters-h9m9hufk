/**
 * E2E-тесты HTTP API.
 *
 * Два режима работы:
 *  1. Внешний сервер (так запускает runner.js): заданы BASE_URL,
 *     FIXTURE_LOCATION_ID и FIXTURE_CATEGORY_ID.
 *  2. Автономный режим (`npm test` / `npm run test:e2e`): тест сам поднимает
 *     приложение на свободном порту с временной SQLite-БД и создаёт фикстуры.
 */
import test, { after, before, describe } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { createApp } from '../index.js';

const EXTERNAL_BASE_URL = process.env.BASE_URL?.trim();
const isExternal = Boolean(EXTERNAL_BASE_URL);

let baseUrl;
let linker = null;
let server = null;
let tempDir = null;
let fixtures;

let sequence = 0;
const uniqueName = (label) => `${label}-${Date.now()}-${++sequence}`;

async function request(method, url, body) {
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: body === undefined ? {} : { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });

  const text = await res.text();
  let parsed = null;

  if (text) {
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = text;
    }
  }

  return { status: res.status, body: parsed };
}

function itemPayload(overrides = {}) {
  return {
    name: uniqueName('Item'),
    properties: { brand: 'Bosch', power: 800 },
    status: 'on_place',
    location_id: fixtures.locationId,
    current_location_id: fixtures.locationId,
    category_id: fixtures.categoryId,
    ...overrides,
  };
}

async function createItem(overrides = {}) {
  return request('POST', '/items', itemPayload(overrides));
}

async function seedFixtures(dbLinker) {
  const structure = await dbLinker.run(
    'insert into structure (name, address) values (?, ?)',
    ['E2E Warehouse', 'Test street 1']
  );
  const floor = await dbLinker.run(
    'insert into floor (name, structure_id) values (?, ?)',
    ['First floor', structure.lastId]
  );
  const room = await dbLinker.run(
    'insert into room (name, floor_id) values (?, ?)',
    ['Storage', floor.lastId]
  );
  const place = await dbLinker.run(
    'insert into place (name, room_id) values (?, ?)',
    ['Rack A', room.lastId]
  );
  const location = await dbLinker.run(
    'insert into location (name, place_id) values (?, ?)',
    ['Shelf 1', place.lastId]
  );
  const category = await dbLinker.run(
    'insert into category (name) values (?)',
    ['Tools']
  );

  return {
    locationId: location.lastId,
    categoryId: category.lastId,
  };
}

before(async () => {
  if (isExternal) {
    baseUrl = EXTERNAL_BASE_URL.replace(/\/+$/, '');
    fixtures = {
      locationId: Number(process.env.FIXTURE_LOCATION_ID),
      categoryId: Number(process.env.FIXTURE_CATEGORY_ID),
    };

    assert.ok(
      Number.isInteger(fixtures.locationId) && fixtures.locationId > 0,
      'FIXTURE_LOCATION_ID должен быть передан при запуске против внешнего сервера'
    );
    assert.ok(
      Number.isInteger(fixtures.categoryId) && fixtures.categoryId > 0,
      'FIXTURE_CATEGORY_ID должен быть передан при запуске против внешнего сервера'
    );
    return;
  }

  tempDir = await mkdtemp(path.join(tmpdir(), 'stackblitz-e2e-'));
  const created = await createApp({ dbFile: path.join(tempDir, 'e2e.db') });
  linker = created.linker;
  fixtures = await seedFixtures(linker);

  server = await new Promise((resolve) => {
    const instance = created.app.listen(0, '127.0.0.1', () => resolve(instance));
  });

  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  if (server) {
    await new Promise((resolve) => server.close(resolve));
  }

  if (linker) {
    await linker.close();
  }

  if (tempDir) {
    await rm(tempDir, { recursive: true, force: true });
  }
});

describe('GET /health', () => {
  test('возвращает 200 и { status: "ok" }', async () => {
    const res = await request('GET', '/health');

    assert.equal(res.status, 200);
    assert.deepEqual(res.body, { status: 'ok' });
  });
});

describe('GET /', () => {
  test('возвращает список доступных эндпоинтов', async () => {
    const res = await request('GET', '/');

    assert.equal(res.status, 200);
    assert.equal(res.body.status, 'ok');
    assert.equal(res.body.endpoints.items, '/items');
    assert.equal(res.body.endpoints.itemById, '/items/:id');
  });

  test('неизвестный маршрут отдаёт JSON 404', async () => {
    const res = await request('GET', '/does-not-exist');

    assert.equal(res.status, 404);
    assert.equal(res.body.status, 404);
    assert.match(res.body.message, /не найден/);
  });
});

describe('POST /items', () => {
  test('создаёт item и возвращает 201 с корректными данными', async () => {
    const name = uniqueName('Drill');

    const res = await createItem({ name });

    assert.equal(res.status, 201);
    assert.ok(res.body.data.id > 0);
    assert.equal(res.body.data.name, name);
    assert.equal(res.body.data.status, 'on_place');
    assert.equal(res.body.data.is_deleted, false);
    assert.deepEqual(res.body.data.properties, {
      brand: 'Bosch',
      power: 800,
    });
    assert.equal(res.body.data.location_id, fixtures.locationId);
  });

  test('созданный item доступен через GET /items/:id', async () => {
    const created = await createItem();
    const res = await request('GET', `/items/${created.body.data.id}`);

    assert.equal(res.status, 200);
    assert.equal(res.body.data.id, created.body.data.id);
    assert.equal(res.body.data.name, created.body.data.name);
  });

  test('пустой name → 400', async () => {
    const res = await createItem({ name: '   ' });

    assert.equal(res.status, 400);
    assert.match(res.body.message, /name/);
  });

  test('неизвестный status → 400', async () => {
    const res = await createItem({ status: 'lost' });

    assert.equal(res.status, 400);
    assert.match(res.body.message, /status/);
  });

  test('несуществующая category_id → 400 (нарушение FK)', async () => {
    const res = await createItem({ category_id: 999_999_999 });

    assert.equal(res.status, 400);
    assert.match(res.body.message, /категория|локация/i);
  });

  test('тело-массив → 400', async () => {
    const res = await request('POST', '/items', []);

    assert.equal(res.status, 400);
    assert.match(res.body.message, /объектом/);
  });
});

describe('GET /items', () => {
  test('фильтрует элементы по ids', async () => {
    const first = await createItem();
    const second = await createItem();

    const res = await request(
      'GET',
      `/items?ids=${first.body.data.id},${second.body.data.id},999999999`
    );

    assert.equal(res.status, 200);

    const ids = res.body.data.map((item) => item.id).sort((a, b) => a - b);
    assert.deepEqual(
      ids,
      [first.body.data.id, second.body.data.id].sort((a, b) => a - b)
    );
  });

  test('некорректный ids → 400', async () => {
    const res = await request('GET', '/items?ids=abc');

    assert.equal(res.status, 400);
    assert.match(res.body.message, /ids/);
  });
});

describe('GET /items/:id', () => {
  test('несуществующий id → 404', async () => {
    const res = await request('GET', '/items/999999999');

    assert.equal(res.status, 404);
    assert.match(res.body.message, /не найден/i);
  });

  test('нечисловой id → 400', async () => {
    const res = await request('GET', '/items/not-a-number');

    assert.equal(res.status, 400);
    assert.match(res.body.message, /id/);
  });
});

describe('PATCH /items/:id', () => {
  test('обновляет только переданные поля', async () => {
    const created = await createItem();
    const name = uniqueName('Saw');

    const res = await request('PATCH', `/items/${created.body.data.id}`, {
      name,
      status: 'broken',
      properties: { brand: 'Makita' },
    });

    assert.equal(res.status, 200);
    assert.equal(res.body.data.name, name);
    assert.equal(res.body.data.status, 'broken');
    assert.deepEqual(res.body.data.properties, { brand: 'Makita' });
    // Поле, которое не передавали, осталось прежним.
    assert.equal(res.body.data.location_id, fixtures.locationId);
  });

  test('пустое тело → 400', async () => {
    const created = await createItem();
    const res = await request('PATCH', `/items/${created.body.data.id}`, {});

    assert.equal(res.status, 400);
    assert.match(res.body.message, /Нет полей/);
  });

  test('неизвестный status → 400', async () => {
    const created = await createItem();
    const res = await request('PATCH', `/items/${created.body.data.id}`, {
      status: 'lost',
    });

    assert.equal(res.status, 400);
    assert.match(res.body.message, /status/);
  });

  test('несуществующий id → 404', async () => {
    const res = await request('PATCH', '/items/999999999', {
      name: uniqueName('Ghost'),
    });

    assert.equal(res.status, 404);
  });
});

describe('DELETE /items/:id', () => {
  test('выполняет soft delete: 200, затем GET → 404 и отсутствие в списке', async () => {
    const created = await createItem();
    const id = created.body.data.id;

    const deleted = await request('DELETE', `/items/${id}`);

    assert.equal(deleted.status, 200);
    assert.deepEqual(deleted.body, { status: 200, message: 'OK' });

    const single = await request('GET', `/items/${id}`);
    assert.equal(single.status, 404);

    const list = await request('GET', `/items?ids=${id}`);
    assert.equal(list.status, 200);
    assert.deepEqual(list.body.data, []);
  });

  test('повторное удаление → 404', async () => {
    const created = await createItem();
    const id = created.body.data.id;

    await request('DELETE', `/items/${id}`);
    const res = await request('DELETE', `/items/${id}`);

    assert.equal(res.status, 404);
  });
});
