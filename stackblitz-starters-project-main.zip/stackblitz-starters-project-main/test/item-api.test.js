import test, { after, before, beforeEach, describe } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { createApp } from '../index.js';

let baseUrl;
let linker;
let server;
let tempDir;
let fixtures;

async function request(method, url, body) {
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: body === undefined ? {} : { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });

  const text = await res.text();

  return {
    status: res.status,
    body: text ? JSON.parse(text) : null,
  };
}

function itemPayload(overrides = {}) {
  return {
    name: 'Drill',
    properties: { brand: 'Bosch', power: 800 },
    status: 'on_place',
    location_id: fixtures.locationId,
    current_location_id: fixtures.locationId,
    category_id: fixtures.categoryId,
    ...overrides,
  };
}

async function createItem(overrides = {}) {
  return request('POST', '/items', itemPayload(overrides));
}

async function seedFixtures() {
  const structure = await linker.run(
    'insert into structure (name, address) values (?, ?)',
    ['Warehouse', 'Main street 1']
  );
  const floor = await linker.run(
    'insert into floor (name, structure_id) values (?, ?)',
    ['First floor', structure.lastId]
  );
  const room = await linker.run(
    'insert into room (name, floor_id) values (?, ?)',
    ['Storage', floor.lastId]
  );
  const place = await linker.run(
    'insert into place (name, room_id) values (?, ?)',
    ['Rack A', room.lastId]
  );
  const location = await linker.run(
    'insert into location (name, place_id) values (?, ?)',
    ['Shelf 1', place.lastId]
  );
  const category = await linker.run(
    'insert into category (name) values (?)',
    ['Tools']
  );

  return {
    locationId: location.lastId,
    categoryId: category.lastId,
  };
}

before(async () => {
  tempDir = await mkdtemp(path.join(tmpdir(), 'stackblitz-items-'));
  const created = await createApp({ dbFile: path.join(tempDir, 'test.db') });
  linker = created.linker;

  server = await new Promise((resolve) => {
    const instance = created.app.listen(0, () => resolve(instance));
  });

  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

beforeEach(async () => {
  await linker.run('delete from item');
  await linker.run('delete from location');
  await linker.run('delete from place');
  await linker.run('delete from room');
  await linker.run('delete from floor');
  await linker.run('delete from structure');
  await linker.run('delete from category');

  fixtures = await seedFixtures();
});

after(async () => {
  if (server) {
    await new Promise((resolve) => server.close(resolve));
  }

  if (linker) {
    await linker.close();
  }

  if (tempDir) {
    await rm(tempDir, { recursive: true, force: true });
  }
});

describe('GET /health', () => {
  test('returns ok', async () => {
    const res = await request('GET', '/health');

    assert.equal(res.status, 200);
    assert.deepEqual(res.body, { status: 'ok' });
  });
});

describe('root route', () => {
  test('returns endpoint list on GET /', async () => {
    const res = await request('GET', '/');

    assert.equal(res.status, 200);
    assert.equal(res.body.status, 'ok');
    assert.equal(res.body.endpoints.items, '/items');
  });

  test('returns a JSON 404 for unknown routes', async () => {
    const res = await request('GET', '/unknown');

    assert.equal(res.status, 404);
    assert.match(res.body.message, /не найден/);
  });
});

describe('POST /items', () => {
  test('creates an item', async () => {
    const res = await createItem();

    assert.equal(res.status, 201);
    assert.equal(res.body.data.name, 'Drill');
    assert.equal(res.body.data.status, 'on_place');
    assert.equal(res.body.data.is_deleted, false);
    assert.deepEqual(res.body.data.properties, {
      brand: 'Bosch',
      power: 800,
    });
    assert.equal(res.body.data.location_id, fixtures.locationId);
  });

  test('rejects a missing name', async () => {
    const res = await request('POST', '/items', itemPayload({ name: '' }));

    assert.equal(res.status, 400);
    assert.match(res.body.message, /name/);
  });

  test('rejects an unknown status', async () => {
    const res = await createItem({ status: 'lost' });

    assert.equal(res.status, 400);
    assert.match(res.body.message, /status/);
  });

  test('rejects a non-existent category', async () => {
    const res = await createItem({ category_id: 999999 });

    assert.equal(res.status, 400);
    assert.match(res.body.message, /категория|локация/i);
  });

  test('rejects a non-object body', async () => {
    const res = await request('POST', '/items', []);

    assert.equal(res.status, 400);
  });
});

describe('GET /items', () => {
  test('returns a list of active items', async () => {
    await createItem({ name: 'First' });
    await createItem({ name: 'Second' });

    const res = await request('GET', '/items');

    assert.equal(res.status, 200);
    assert.equal(res.body.data.length, 2);
    assert.deepEqual(
      res.body.data.map((item) => item.name),
      ['First', 'Second']
    );
  });

  test('filters items by ids', async () => {
    const first = await createItem({ name: 'First' });
    await createItem({ name: 'Second' });

    const res = await request(
      'GET',
      `/items?ids=${first.body.data.id},999999`
    );

    assert.equal(res.status, 200);
    assert.equal(res.body.data.length, 1);
    assert.equal(res.body.data[0].id, first.body.data.id);
  });

  test('rejects invalid ids filter', async () => {
    const res = await request('GET', '/items?ids=abc');

    assert.equal(res.status, 400);
  });
});

describe('GET /items/:id', () => {
  test('returns one item', async () => {
    const created = await createItem();

    const res = await request('GET', `/items/${created.body.data.id}`);

    assert.equal(res.status, 200);
    assert.equal(res.body.data.id, created.body.data.id);
  });

  test('returns 404 for an unknown item', async () => {
    const res = await request('GET', '/items/999999');

    assert.equal(res.status, 404);
  });

  test('returns 400 for an invalid id', async () => {
    const res = await request('GET', '/items/not-a-number');

    assert.equal(res.status, 400);
  });
});

describe('PATCH /items/:id', () => {
  test('updates only the provided fields', async () => {
    const created = await createItem();

    const res = await request('PATCH', `/items/${created.body.data.id}`, {
      name: 'Saw',
      properties: { brand: 'Makita' },
      status: 'broken',
    });

    assert.equal(res.status, 200);
    assert.equal(res.body.data.name, 'Saw');
    assert.equal(res.body.data.status, 'broken');
    assert.deepEqual(res.body.data.properties, { brand: 'Makita' });
    assert.equal(res.body.data.location_id, fixtures.locationId);
  });

  test('rejects an empty body', async () => {
    const created = await createItem();

    const res = await request('PATCH', `/items/${created.body.data.id}`, {});

    assert.equal(res.status, 400);
  });

  test('rejects an invalid status', async () => {
    const created = await createItem();

    const res = await request('PATCH', `/items/${created.body.data.id}`, {
      status: 'lost',
    });

    assert.equal(res.status, 400);
  });

  test('returns 404 for an unknown item', async () => {
    const res = await request('PATCH', '/items/999999', { name: 'Saw' });

    assert.equal(res.status, 404);
  });
});

describe('DELETE /items/:id', () => {
  test('soft deletes an item', async () => {
    const created = await createItem();
    const id = created.body.data.id;

    const res = await request('DELETE', `/items/${id}`);

    assert.equal(res.status, 200);
    assert.deepEqual(res.body, { status: 200, message: 'OK' });

    const single = await request('GET', `/items/${id}`);
    assert.equal(single.status, 404);

    const list = await request('GET', '/items');
    assert.equal(list.body.data.length, 0);

    const row = await linker.get(
      'select is_deleted from item where id = ?',
      [id]
    );
    assert.equal(row.is_deleted, 1);
  });

  test('returns 404 when deleting twice', async () => {
    const created = await createItem();
    const id = created.body.data.id;

    await request('DELETE', `/items/${id}`);
    const res = await request('DELETE', `/items/${id}`);

    assert.equal(res.status, 404);
  });
});
