import test, { describe } from 'node:test';
import assert from 'node:assert/strict';
import {
  isEmpty,
  isNotEmpty,
  isNotEmptyArray,
  isCorrectStatus,
} from '../utils.js';
import SqliteLinker from '../db/sqlite.js';
import ItemService from '../item/item-service.js';
import StructureDto from '../db/dtos/structure_dto.js';
import FloorDto from '../db/dtos/floor_dto.js';
import ItemEntity from '../item/item-entity.js';
import { EItemStatus } from '../db/enums.js';

describe('utils', () => {
  test('isEmpty', () => {
    assert.equal(isEmpty(undefined), true);
    assert.equal(isEmpty(null), true);
    assert.equal(isEmpty(''), true);
    assert.equal(isEmpty({}), true);
    assert.equal(isEmpty('x'), false);
    assert.equal(isEmpty(0), false);
    assert.equal(isEmpty([]), false);
  });

  test('isNotEmpty / isNotEmptyArray', () => {
    assert.equal(isNotEmpty('x'), true);
    assert.equal(isNotEmpty({}), false);
    assert.equal(isNotEmptyArray([]), false);
    assert.equal(isNotEmptyArray([1]), true);
    assert.equal(isNotEmptyArray('x'), false);
  });

  test('isCorrectStatus', () => {
    assert.equal(isCorrectStatus(EItemStatus, 'broken'), true);
    assert.equal(isCorrectStatus(EItemStatus, 'lost'), false);
  });
});

describe('SqliteLinker helpers', () => {
  const linker = new SqliteLinker(':memory:');

  test('createPlaceHolders', () => {
    assert.equal(linker.createPlaceHolders([1, 2, 3]), '?, ?, ?');
    assert.equal(linker.createPlaceHolders([]), '');
  });

  test('createSetBlock skips empty values', () => {
    assert.deepEqual(
      linker.createSetBlock({
        name: 'Saw',
        status: '',
        properties: {},
        category_id: 3,
      }),
      {
        block: 'name = ?, category_id = ?',
        values: ['Saw', 3],
      }
    );
  });
});

describe('ItemService.normalizeIds', () => {
  test('parses comma-separated, array and invalid values', () => {
    assert.deepEqual(ItemService.normalizeIds('1,2,2,3'), [1, 2, 3]);
    assert.deepEqual(ItemService.normalizeIds(['4', '5']), [4, 5]);
    assert.deepEqual(ItemService.normalizeIds('abc,0,-1,2'), [2]);
    assert.deepEqual(ItemService.normalizeIds(undefined), []);
  });
});

describe('ItemEntity', () => {
  test('maps a database row', () => {
    const entity = ItemEntity.fromRow({
      id: 1,
      is_deleted: 0,
      properties: '{"a":1}',
    });

    assert.equal(entity.is_deleted, false);
    assert.deepEqual(entity.properties, { a: 1 });
  });

  test('handles null and invalid JSON', () => {
    assert.equal(ItemEntity.fromRow(null), null);
    assert.equal(ItemEntity.parseProperties('not json'), 'not json');
  });
});

describe('DTOs', () => {
  test('StructureDto returns a valid object', () => {
    const dto = new StructureDto({ name: 'Warehouse', address: 'Street 1' });

    assert.deepEqual(dto.object, {
      name: 'Warehouse',
      address: 'Street 1',
    });
  });

  test('StructureDto rejects invalid data', () => {
    const dto = new StructureDto({ name: '', address: 'Street 1' });

    assert.throws(() => dto.object, /Try another data/);
  });

  test('FloorDto rejects invalid structure_id', () => {
    const dto = new FloorDto({ name: 'First', structure_id: -1 });

    assert.throws(() => dto.object, /Try another data/);
  });

  test('FloorDto returns a valid object', () => {
    const dto = new FloorDto({ name: 'First', structure_id: 1 });

    assert.deepEqual(dto.object, { name: 'First', structure_id: 1 });
  });
});
