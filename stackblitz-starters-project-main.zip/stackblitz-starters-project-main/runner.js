#!/usr/bin/env node
/**
 * Полный цикл автоматизации тестирования:
 *   1. проверяет/устанавливает зависимости;
 *   2. создаёт временную SQLite-БД, применяет миграции и фикстуры;
 *   3. поднимает локальный сервер в фоновом процессе;
 *   4. ждёт готовности /health;
 *   5. запускает тесты (node:test) против живого сервера;
 *   6. останавливает сервер, удаляет временные файлы и печатает отчёт.
 *
 * Запуск:  npm run test:runner
 */
import { spawn } from 'node:child_process';
import { constants } from 'node:fs';
import { access, mkdtemp, rm } from 'node:fs/promises';
import { createServer } from 'node:net';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import SqliteLinker from './db/sqlite.js';
import { runMigrations } from './db/migration.js';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const IS_WINDOWS = process.platform === 'win32';
const HEALTH_TIMEOUT_MS = Number(process.env.HEALTH_TIMEOUT_MS) || 20_000;
const SERVER_STOP_TIMEOUT_MS = 5_000;

const report = {
  dependencies: 'не проверялись',
  server: 'не запускался',
  tests: 'не запускались',
};

let serverProcess = null;
let tempDir = null;

const log = (message) => console.log(`[runner] ${message}`);
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function fileExists(file) {
  try {
    await access(file, constants.F_OK);
    return true;
  } catch {
    return false;
  }
}

function runCommand(command, args, options = {}) {
  return new Promise((resolve) => {
    const child = spawn(command, args, {
      cwd: ROOT,
      stdio: 'inherit',
      ...options,
    });

    child.on('error', (error) => resolve({ code: 1, signal: null, error }));
    child.on('exit', (code, signal) => resolve({ code: code ?? 1, signal }));
  });
}

async function ensureDependencies() {
  const nodeModules = path.join(ROOT, 'node_modules');
  const sqlitePackage = path.join(nodeModules, 'sqlite3', 'package.json');

  if ((await fileExists(nodeModules)) && (await fileExists(sqlitePackage))) {
    report.dependencies = 'OK (уже установлены)';
    log('Зависимости уже установлены, npm install не требуется');
    return;
  }

  log('Устанавливаю зависимости: npm install');
  const npm = IS_WINDOWS ? 'npm.cmd' : 'npm';
  const result = await runCommand(npm, ['install', '--no-audit', '--no-fund'], {
    shell: IS_WINDOWS,
  });

  if (result.code !== 0) {
    report.dependencies = 'FAIL';
    throw new Error(
      `npm install завершился с кодом ${result.code}${
        result.error ? `: ${result.error.message}` : ''
      }`
    );
  }

  report.dependencies = 'OK (установлены)';
}

function getFreePort() {
  return new Promise((resolve, reject) => {
    const probe = createServer();

    probe.unref();
    probe.on('error', reject);
    probe.listen(0, '127.0.0.1', () => {
      const { port } = probe.address();
      probe.close((error) => (error ? reject(error) : resolve(port)));
    });
  });
}

async function seedFixtures(dbFile) {
  const linker = new SqliteLinker(dbFile);
  await linker.connect();

  try {
    await runMigrations(linker);

    const structure = await linker.run(
      'insert into structure (name, address) values (?, ?)',
      ['Runner Warehouse', 'Runner street 1']
    );
    const floor = await linker.run(
      'insert into floor (name, structure_id) values (?, ?)',
      ['First floor', structure.lastId]
    );
    const room = await linker.run(
      'insert into room (name, floor_id) values (?, ?)',
      ['Storage', floor.lastId]
    );
    const place = await linker.run(
      'insert into place (name, room_id) values (?, ?)',
      ['Rack A', room.lastId]
    );
    const location = await linker.run(
      'insert into location (name, place_id) values (?, ?)',
      ['Shelf 1', place.lastId]
    );
    const category = await linker.run(
      'insert into category (name) values (?)',
      ['Tools']
    );

    return {
      locationId: location.lastId,
      categoryId: category.lastId,
    };
  } finally {
    await linker.close();
  }
}

function startServer(port, dbFile) {
  const child = spawn(process.execPath, ['index.js'], {
    cwd: ROOT,
    env: {
      ...process.env,
      PORT: String(port),
      DB_FILE: dbFile,
      NODE_ENV: 'test',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  let output = '';
  const collect = (chunk) => {
    const text = chunk.toString();
    output += text;
    process.stdout.write(`[server] ${text}`);
  };

  child.stdout.on('data', collect);
  child.stderr.on('data', collect);

  return {
    child,
    getOutput: () => output,
  };
}

async function waitForHealth(baseUrl, server, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let lastError = null;

  while (Date.now() < deadline) {
    if (server.child.exitCode !== null) {
      throw new Error(
        `Сервер завершился до старта (код ${server.child.exitCode}).\n${server.getOutput()}`
      );
    }

    try {
      const res = await fetch(`${baseUrl}/health`, {
        signal: AbortSignal.timeout(1_000),
      });

      if (res.ok) {
        const body = await res.json();
        if (body.status === 'ok') return;
      }

      lastError = new Error(`/health вернул HTTP ${res.status}`);
    } catch (error) {
      lastError = error;
    }

    await sleep(200);
  }

  throw new Error(
    `Сервер не ответил за ${timeoutMs} мс: ${
      lastError?.message ?? 'неизвестная ошибка'
    }\n${server.getOutput()}`
  );
}

async function stopServer(server) {
  if (!server || server.child.exitCode !== null) return;

  const exited = new Promise((resolve) => server.child.once('exit', resolve));
  server.child.kill('SIGTERM');

  const timedOut = await Promise.race([
    exited.then(() => false),
    sleep(SERVER_STOP_TIMEOUT_MS).then(() => true),
  ]);

  if (timedOut && server.child.exitCode === null) {
    log('Сервер не остановился по SIGTERM, завершаю принудительно');
    server.child.kill('SIGKILL');
    await Promise.race([exited, sleep(2_000)]);
  }
}

async function runTests(env) {
  // Явно передаём обе папки: tests/ (E2E против живого сервера) и test/ (юнит + in-process API).
  return runCommand(process.execPath, ['--test', 'tests', 'test'], {
    env: { ...process.env, ...env },
  });
}

function printReport(durationMs) {
  const line = '='.repeat(52);

  console.log(`\n${line}`);
  console.log('  ОТЧЁТ О ТЕСТИРОВАНИИ');
  console.log(line);
  console.log(`  Зависимости : ${report.dependencies}`);
  console.log(`  Сервер      : ${report.server}`);
  console.log(`  Тесты       : ${report.tests}`);
  console.log(`  Длительность: ${(durationMs / 1000).toFixed(2)} с`);
  console.log(
    `  Итог        : ${process.exitCode === 0 ? 'PASS ✅' : 'FAIL ❌'}`
  );
  console.log(`${line}\n`);
}

async function main() {
  const startedAt = Date.now();

  log(`Node ${process.version}, платформа ${process.platform}`);

  try {
    await ensureDependencies();

    tempDir = await mkdtemp(path.join(tmpdir(), 'stackblitz-runner-'));
    const dbFile = path.join(tempDir, 'test.db');

    log('Создаю временную БД и применяю миграции/фикстуры');
    const fixtures = await seedFixtures(dbFile);

    const port = await getFreePort();
    const baseUrl = `http://127.0.0.1:${port}`;

    log(`Запускаю сервер на ${baseUrl} (БД: ${dbFile})`);
    serverProcess = startServer(port, dbFile);

    await waitForHealth(baseUrl, serverProcess, HEALTH_TIMEOUT_MS);
    report.server = `OK (${baseUrl})`;
    log('Сервер готов, запускаю тесты');

    const result = await runTests({
      BASE_URL: baseUrl,
      FIXTURE_LOCATION_ID: String(fixtures.locationId),
      FIXTURE_CATEGORY_ID: String(fixtures.categoryId),
    });

    report.tests = result.code === 0 ? 'PASS' : `FAIL (код ${result.code})`;
    process.exitCode = result.code;
  } catch (error) {
    console.error(`[runner] Ошибка: ${error.message}`);

    if (report.server === 'не запускался') report.server = 'FAIL';
    if (report.tests === 'не запускались') report.tests = 'не запускались';

    process.exitCode = 1;
  } finally {
    await stopServer(serverProcess);

    if (tempDir) {
      await rm(tempDir, {
        recursive: true,
        force: true,
        maxRetries: 5,
        retryDelay: 100,
      }).catch((error) => {
        log(`Не удалось удалить временную папку: ${error.message}`);
      });
    }

    printReport(Date.now() - startedAt);
  }
}

await main();
