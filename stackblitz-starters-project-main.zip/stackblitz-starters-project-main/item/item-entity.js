/**
 * Представление item на уровне приложения.
 * Приводит строку из SQLite к удобному для API виду: properties — объект,
 * is_deleted — boolean.
 */
export default class ItemEntity {
  static fromRow(row) {
    if (!row) return null;

    return {
      ...row,
      is_deleted: Boolean(row.is_deleted),
      properties: ItemEntity.parseProperties(row.properties),
    };
  }

  static parseProperties(value) {
    if (typeof value !== 'string') return value ?? {};

    try {
      return JSON.parse(value);
    } catch {
      return value;
    }
  }

  static serializeProperties(value) {
    return typeof value === 'string' ? value : JSON.stringify(value);
  }
}
