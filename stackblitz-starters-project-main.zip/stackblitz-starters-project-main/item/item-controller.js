import { EItemStatus } from '../db/enums.js';
import { isCorrectStatus, isNotEmpty, isString } from '../utils.js';
import ItemService from './item-service.js';

const ITEM_FIELDS = [
  'name',
  'properties',
  'status',
  'location_id',
  'current_location_id',
  'category_id',
];

export default class ItemController {
  constructor(service = new ItemService()) {
    this.service = service;
  }

  async getItem(ctx) {
    const id = this.#parseId(ctx.params.id);
    if (id === null) return this.#badRequest(ctx, 'Некорректный id');

    const res = await this.service.getOne(id);

    if (!res) return this.#notFound(ctx);

    ctx.status = 200;
    ctx.body = {
      data: res,
    };
  }

  async getItems(ctx) {
    const { ids } = ctx.query;

    if (
      ids !== undefined &&
      ids !== '' &&
      ItemService.normalizeIds(ids).length === 0
    ) {
      return this.#badRequest(ctx, 'Параметр ids должен содержать id через запятую');
    }

    const res = await this.service.getAll({ ids });

    ctx.status = 200;
    ctx.body = {
      data: res,
    };
  }

  async deleteItem(ctx) {
    const id = this.#parseId(ctx.params.id);
    if (id === null) return this.#badRequest(ctx, 'Некорректный id');

    const deleted = await this.service.softDelete(id);

    if (!deleted) return this.#notFound(ctx);

    ctx.status = 200;
    ctx.body = {
      status: 200,
      message: 'OK',
    };
  }

  async updateItem(ctx) {
    const id = this.#parseId(ctx.params.id);
    if (id === null) return this.#badRequest(ctx, 'Некорректный id');

    const body = this.#getBody(ctx);
    if (!body) return this.#badRequest(ctx, 'Тело запроса должно быть объектом');

    const data = {};
    for (const field of ITEM_FIELDS) {
      if (Object.hasOwn(body, field)) data[field] = body[field];
    }

    if (Object.keys(data).length === 0) {
      return this.#badRequest(ctx, 'Нет полей для обновления');
    }

    const validationError = this.#validateItemData(data, { partial: true });
    if (validationError) return this.#badRequest(ctx, validationError);

    try {
      const res = await this.service.update(id, data);

      if (!res) return this.#notFound(ctx);

      ctx.status = 200;
      ctx.body = {
        data: res,
      };
    } catch (err) {
      if (this.#isConstraintError(err)) {
        return this.#badRequest(
          ctx,
          'Указанная категория или локация не существует'
        );
      }

      throw err;
    }
  }

  async createItem(ctx) {
    const body = this.#getBody(ctx);
    if (!body) return this.#badRequest(ctx, 'Тело запроса должно быть объектом');

    const data = {
      name: body.name,
      properties: body.properties,
      status: body.status,
      location_id: body.location_id,
      current_location_id: body.current_location_id,
      category_id: body.category_id,
    };

    const validationError = this.#validateItemData(data);
    if (validationError) return this.#badRequest(ctx, validationError);

    try {
      const res = await this.service.create(data);

      ctx.status = 201;
      ctx.body = {
        data: res,
      };
    } catch (err) {
      if (this.#isConstraintError(err)) {
        return this.#badRequest(
          ctx,
          'Указанная категория или локация не существует'
        );
      }

      throw err;
    }
  }

  #getBody(ctx) {
    const body = ctx.request.body;

    if (body === undefined || body === null) return null;
    if (typeof body !== 'object' || Array.isArray(body)) return null;

    return body;
  }

  #validateItemData(data, { partial = false } = {}) {
    if (!partial || Object.hasOwn(data, 'name')) {
      if (!isString(data.name) || !isNotEmpty(data.name.trim())) {
        return 'Поле name должно быть непустой строкой';
      }
    }

    if (!partial || Object.hasOwn(data, 'properties')) {
      if (
        typeof data.properties !== 'object' ||
        data.properties === null ||
        Array.isArray(data.properties) ||
        !isNotEmpty(data.properties)
      ) {
        return 'Поле properties должно быть непустым объектом';
      }
    }

    if (!partial || Object.hasOwn(data, 'status')) {
      if (!isCorrectStatus(EItemStatus, data.status)) {
        return `Поле status должно быть одним из: ${Object.values(
          EItemStatus
        ).join(', ')}`;
      }
    }

    for (const field of [
      'location_id',
      'current_location_id',
      'category_id',
    ]) {
      if (!partial || Object.hasOwn(data, field)) {
        if (!this.#isPositiveInteger(data[field])) {
          return `Поле ${field} должно быть положительным целым числом`;
        }
      }
    }

    return null;
  }

  #parseId(value) {
    const id = Number(value);

    return this.#isPositiveInteger(id) ? id : null;
  }

  #isPositiveInteger(value) {
    const number = Number(value);
    return Number.isInteger(number) && number > 0;
  }

  #isConstraintError(err) {
    return (
      err?.code?.startsWith?.('SQLITE_CONSTRAINT') ||
      /constraint|foreign key/i.test(err?.message ?? '')
    );
  }

  #badRequest(ctx, message) {
    ctx.status = 400;
    ctx.body = {
      status: 400,
      message,
    };
  }

  #notFound(ctx) {
    ctx.status = 404;
    ctx.body = {
      status: 404,
      message: 'Item не найден',
    };
  }
}
