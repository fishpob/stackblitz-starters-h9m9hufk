import path from 'node:path';
import SqliteLinker from './sqlite.js';
import { runMigrations } from './migration.js';

const filename =
  process.argv[2] || process.env.DB_FILE || path.resolve('database.db');

const linker = new SqliteLinker(filename);
await linker.connect();

try {
  await runMigrations(linker);
  console.log(`Migrations applied to ${filename}`);
} finally {
  await linker.close();
}
