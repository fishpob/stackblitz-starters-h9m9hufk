import { readdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const migrationsDir = fileURLToPath(new URL('./migrations', import.meta.url));

/**
 * Применяет все ещё не выполненные миграции из папки db/migrations.
 * Каждый файл экспортирует функцию up(linker), которая получает уже открытое
 * соединение с БД. Применённые миграции записываются в schema_migrations.
 */
export async function runMigrations(linker, directory = migrationsDir) {
  await linker.run(`
    create table if not exists schema_migrations (
      name text primary key,
      applied_at text not null default current_timestamp
    )
  `);

  const files = (await readdir(directory))
    .filter((file) => file.endsWith('.js'))
    .sort();

  for (const file of files) {
    const applied = await linker.get(
      'select name from schema_migrations where name = ?',
      [file]
    );

    if (applied) continue;

    const migration = await import(
      pathToFileURL(path.join(directory, file)).href
    );

    if (typeof migration.up !== 'function') {
      throw new Error(`Migration ${file} must export an up(linker) function`);
    }

    await linker.run('begin');

    try {
      await migration.up(linker);
      await linker.run('insert into schema_migrations (name) values (?)', [file]);
      await linker.run('commit');
    } catch (err) {
      await linker.run('rollback');
      throw err;
    }
  }

  return files;
}
